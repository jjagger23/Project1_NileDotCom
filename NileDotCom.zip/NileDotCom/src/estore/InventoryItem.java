package estore;

/*
    Name:  Joshua Jaggernauth
    Course: CNT 4714 – Fall 2025
    Assignment title: Project 1 – An Event-driven Enterprise Simulation
    Date: Sunday September 7, 2025
*/

/**
 * Represents a single inventory item loaded from inventory.csv.
 * This is a simple immutable data holder (no setters).
 *
 * Fields map directly to CSV columns:
 *   id             → item identifier
 *   description    → item description (may come from quoted text)
 *   inStock        → whether the item is available for sale
 *   quantityOnHand → number of units available
 *   unitPrice      → price per unit
 */

public class InventoryItem {

	private final String id;

	private final String description;

	private final boolean inStock; // parsed from CSV ("true"/"yes"/"y" → true)
	private final int quantityOnHand; // QOH value from CSV
	private final double unitPrice; // unit price in dollars

	/**
	 * Constructs an immutable InventoryItem.
	 */

	public InventoryItem(String id, String description, boolean inStock, int quantityOnHand, double unitPrice) {
		this.id = id;
		this.description = description;
		this.inStock = inStock;
		this.quantityOnHand = quantityOnHand;
		this.unitPrice = unitPrice;
	}

	// --- Getters (no setters, since we treat inventory as read-only once loaded) ---
	public String getId() {
		return id;
	}

	public String getDescription() {
		return description;
	}

	public boolean isInStock() {
		return inStock;
	}

	public int getQuantityOnHand() {
		return quantityOnHand;
	}

	public double getUnitPrice() {
		return unitPrice;
	}
}