package estore;

import javax.swing.*;
import javax.swing.text.JTextComponent;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.text.NumberFormat;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;

/*
    Name:  Joshua Jaggernauth
    Course: CNT 4714 – Fall 2025
    Assignment title: Project 1 – An Event-driven Enterprise Simulation
    Date: Sunday September 7, 2025
*/

/**
 * Main GUI for the Nile Dot Com assignment.
 * Responsibilities:
 *  - Load inventory from CSV (via CSVLoader)
 *  - Let the user Find / Add / Delete items (max 5 lines)
 *  - Compute discounts, subtotal, tax, total
 *  - Show an invoice and append to transactions.csv on checkout
 *
 * Design notes:
 *  - Nimbus Look & Feel for a clean built-in look (no external jars)
 *  - Button state drives the flow (Find → Add → Find ...; Delete/Checkout enabled when cart has items)
 *  - Two centered rows of actions to match the project’s expected layout
 */

public class NileStoreApp extends JFrame {

	private static final long serialVersionUID = 1L;

	// ===== UI components =====
	private final JTextField itemIdField = new JTextField(12);

	private final JTextField qtyField = new JTextField(6);

	private final JTextArea itemInfoArea = new JTextArea(4, 40); // preview of the currently found line
	private final JTextArea cartArea = new JTextArea(12, 40); // running cart contents
	private final JLabel subtotalLabel = new JLabel("Order subtotal: $0.00");

	private final JButton findButton = new JButton("Find Item #1");

	private final JButton addButton = new JButton("Add Item #1 To Cart");

	private final JButton deleteLastButton = new JButton("Delete Last Item From Cart");

	private final JButton checkoutButton = new JButton("Check Out");

	private final JButton newOrderButton = new JButton("Start New Order");

	private final JButton exitButton = new JButton("Exit");

	// ===== State =====
	private int itemIndex = 1; // display index 1..5 (cart line #); max 5 items per spec
	private Map<String, InventoryItem> inventory; // read once from inventory.csv at startup
	private InventoryItem pendingItem = null; // the last "found" item not yet added
	private int pendingQty = 0;

	private final List<CartLine> cart = new ArrayList<>();

	private double subtotal = 0.0;

	private static final double TAX_RATE = 0.06; // per project spec
	private final NumberFormat currency = NumberFormat.getCurrencyInstance(Locale.US);

	/**
	 * Immutable cart line (computed line total includes any discount).
	 */

	private static class CartLine {
		final String id;
		final String description;
		final int qty;
		final double unitPrice;
		final double discountRate; // 0.00..0.20
		final double lineTotal; // qty * unitPrice * (1 - discount)
		CartLine(String id, String description, int qty, double unitPrice, double discountRate) {
			this.id = id;
			this.description = description;
			this.qty = qty;
			this.unitPrice = unitPrice;
			this.discountRate = discountRate;
			this.lineTotal = qty * unitPrice * (1.0 - discountRate);
		}
	}

	// ===== Constructor =====
	public NileStoreApp() {
		super("Nile Dot Com - (Event-Driven Programming)");

		// --- Top: entry panel (ID, Qty, Find) ---
		JPanel entry = new JPanel(new GridBagLayout());
		GridBagConstraints gc = new GridBagConstraints();
		gc.insets = new Insets(4, 4, 4, 4);

		gc.gridx = 0;
		gc.gridy = 0;
		gc.anchor = GridBagConstraints.EAST;
		entry.add(new JLabel("Enter Item ID:"), gc);
		gc.gridx = 1;
		gc.anchor = GridBagConstraints.WEST;
		entry.add(itemIdField, gc);

		gc.gridx = 0;
		gc.gridy = 1;
		gc.anchor = GridBagConstraints.EAST;
		entry.add(new JLabel("Enter Quantity:"), gc);
		gc.gridx = 1;
		gc.anchor = GridBagConstraints.WEST;
		entry.add(qtyField, gc);

		gc.gridx = 2;
		gc.gridy = 0;
		gc.gridheight = 2;
		gc.fill = GridBagConstraints.VERTICAL;
		entry.add(findButton, gc);

		// --- Middle: selected item info + subtotal + cart ---
		itemInfoArea.setEditable(false);
		cartArea.setEditable(false);
		JScrollPane itemInfoScroll = new JScrollPane(itemInfoArea);
		JScrollPane cartScroll = new JScrollPane(cartArea);

		JPanel topInfo = new JPanel(new BorderLayout());
		topInfo.add(new JLabel("Selected Item Info:"), BorderLayout.NORTH);
		topInfo.add(itemInfoScroll, BorderLayout.CENTER);
		topInfo.add(subtotalLabel, BorderLayout.SOUTH);

		JPanel cartPanel = new JPanel(new BorderLayout());
		cartPanel.add(new JLabel("Shopping Cart (max 5 items):"), BorderLayout.NORTH);
		cartPanel.add(cartScroll, BorderLayout.CENTER);

		JPanel middle = new JPanel(new BorderLayout(8, 8));
		middle.add(topInfo, BorderLayout.NORTH);
		middle.add(cartPanel, BorderLayout.CENTER);

		// --- Bottom: two centered rows to match assignment layout ---
		JPanel bottom = new JPanel(new BorderLayout());
		bottom.setBorder(BorderFactory.createEmptyBorder(8, 0, 0, 0));

		JPanel rows = new JPanel(new GridLayout(2, 1, 0, 8));

		// Row 1: Add + Delete (centered)
		JPanel row1 = new JPanel(new FlowLayout(FlowLayout.CENTER, 16, 0));
		row1.add(addButton);
		row1.add(deleteLastButton);

		// Row 2: Checkout + New Order + Exit (centered)
		JPanel row2 = new JPanel(new FlowLayout(FlowLayout.CENTER, 16, 0));
		row2.add(checkoutButton);
		row2.add(newOrderButton);
		row2.add(exitButton);

		rows.add(row1);
		rows.add(row2);
		bottom.add(rows, BorderLayout.CENTER);

		// --- Frame layout ---
		setLayout(new BorderLayout(10, 10));
		add(entry, BorderLayout.NORTH);
		add(middle, BorderLayout.CENTER);
		add(bottom, BorderLayout.SOUTH);

		// Initial enabled/disabled state enforces flow (Find → Add; actions gated by cart size)
		addButton.setEnabled(false);
		deleteLastButton.setEnabled(false);
		checkoutButton.setEnabled(false);

		// Keyboard mnemonics for quick access
		findButton.setMnemonic('F');
		addButton.setMnemonic('A');
		deleteLastButton.setMnemonic('D');
		checkoutButton.setMnemonic('C');
		newOrderButton.setMnemonic('N');
		exitButton.setMnemonic('X');

		// Handlers (business logic is split into small methods below)
		newOrderButton.addActionListener(e -> resetForNewOrder());
		exitButton.addActionListener(e -> System.exit(0)); // explicit app close per assignment UI
		findButton.addActionListener(this::onFindItem);
		addButton.addActionListener(e -> onAddToCart());
		deleteLastButton.addActionListener(e -> onDeleteLast());
		checkoutButton.addActionListener(e -> onCheckout());

		// ENTER triggers Find initially (we switch the default button contextually)
		getRootPane().setDefaultButton(findButton);

		// Frame config
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(880, 600); // slightly larger window for comfortable layout
		setLocationRelativeTo(null);

		// Load inventory at startup (must exist in project root)
		try {
			inventory = CSVLoader.loadInventory("inventory.csv");
		} catch (IOException ex) {
			JOptionPane.showMessageDialog(this,
				"Could not read inventory.csv.\nPlace it in the project root (same level as src/) and refresh the project.",
				"Inventory Load Error", JOptionPane.ERROR_MESSAGE);
		}

		// Visual tweaks + right-click Copy/Paste menus
		applyStyling();
		installContextMenus();
	}

	// ===== Behavior: Find Item =====

	/**
	 * Validate input, look up the item, verify stock/quantity,
	 * preview the priced line (with discount), and arm the Add step.
	 */

	private void onFindItem(ActionEvent evt) {
		pendingItem = null;
		pendingQty = 0;

		String id = itemIdField.getText().trim();
		String qtyStr = qtyField.getText().trim();

		if (id.isEmpty()) {
			JOptionPane.showMessageDialog(this, "Please enter an Item ID.");
			itemIdField.requestFocusInWindow();
			return;
		}

		int qty;
		try {
			qty = Integer.parseInt(qtyStr);

			if (qty <= 0) throw new NumberFormatException();
		} catch (NumberFormatException nfe) {
			JOptionPane.showMessageDialog(this, "Please enter a valid, positive quantity.");
			qtyField.requestFocusInWindow();
			qtyField.selectAll();
			return;
		}

		if (inventory == null || inventory.isEmpty()) {
			JOptionPane.showMessageDialog(this, "Inventory is empty or not loaded.");
			return;
		}

		InventoryItem item = inventory.get(id);

		if (item == null) {
			JOptionPane.showMessageDialog(this,
				"The item ID " + id + " was not found in the inventory.",
				"Item Not Found", JOptionPane.WARNING_MESSAGE);
			itemIdField.setText("");
			qtyField.setText("");
			itemIdField.requestFocusInWindow();
			return;
		}

		if (!item.isInStock()) {
			JOptionPane.showMessageDialog(this,
				"The item \"" + item.getDescription() + "\" is currently NOT IN STOCK.\nPlease enter another item.",
				"Not In Stock", JOptionPane.WARNING_MESSAGE);
			itemIdField.setText("");
			qtyField.setText("");
			itemIdField.requestFocusInWindow();
			return;
		}

		if (qty > item.getQuantityOnHand()) {
			JOptionPane.showMessageDialog(this,
				"Insufficient quantity in stock. Only " + item.getQuantityOnHand() + " available.",
				"Insufficient Quantity", JOptionPane.WARNING_MESSAGE);
			qtyField.setText("");
			qtyField.requestFocusInWindow();
			return;
		}

		// Valid: build preview text with discount applied
		double discountRate = discountFor(qty);
		double lineTotal = item.getUnitPrice() * qty * (1.0 - discountRate);

		String info = String.format(
			"Item #%d: %s  \"%s\"  Unit: %s  Qty: %d  Discount: %.0f%%  Line total: %s",
			itemIndex, item.getId(), item.getDescription(),
			currency.format(item.getUnitPrice()), qty, discountRate * 100.0, currency.format(lineTotal)
		);
		itemInfoArea.setText(info);

		// Stash selection for Add
		pendingItem = item;
		pendingQty = qty;

		// Lock inputs and enable Add to enforce the find→add flow
		addButton.setEnabled(true);
		findButton.setEnabled(false);
		itemIdField.setEditable(false);
		qtyField.setEditable(false);

		// ENTER now triggers Add
		getRootPane().setDefaultButton(addButton);
	}

	/**
	 * Discount schedule per assignment spec.
	 */

	private static double discountFor(int qty) {
		if (qty >= 15) return 0.20;

		if (qty >= 10) return 0.15;

		if (qty >= 5) return 0.10;
		return 0.0;
	}

	// ===== Behavior: Add Item To Cart =====

	/**
	 * Commit the pending line to the cart, update totals,
	 * refresh UI state, and advance the line counter (cap at 5 lines).
	 */

	private void onAddToCart() {
		if (pendingItem == null || pendingQty <= 0) {
			JOptionPane.showMessageDialog(this, "Find a valid item first.");
			return;
		}

		if (cart.size() >= 5) {
			JOptionPane.showMessageDialog(this,
				"Cart is full (max 5 items). Check out, delete the last item, or start a new order.",
				"Cart Full", JOptionPane.WARNING_MESSAGE);
			return;
		}

		double rate = discountFor(pendingQty);
		CartLine line = new CartLine(
			pendingItem.getId(), pendingItem.getDescription(),
			pendingQty, pendingItem.getUnitPrice(), rate
		);
		cart.add(line);
		subtotal += line.lineTotal;

		renderCart();
		subtotalLabel.setText("Order subtotal: " + currency.format(subtotal));

		// Advance the display index up to 5
		itemIndex++;

		if (itemIndex > 5) itemIndex = 5;

		findButton.setText("Find Item #" + itemIndex);
		addButton.setText("Add Item #" + itemIndex + " To Cart");

		// Reset inputs for next search
		itemInfoArea.setText("");
		itemIdField.setText("");
		qtyField.setText("");
		itemIdField.setEditable(true);
		qtyField.setEditable(true);
		findButton.setEnabled(true);
		addButton.setEnabled(false);

		// Now that cart has at least one line, allow delete/checkout
		deleteLastButton.setEnabled(true);
		checkoutButton.setEnabled(true);

		// Clear pending selection
		pendingItem = null;
		pendingQty = 0;

		// If cart reached capacity, prevent further finds
		if (cart.size() >= 5) {
			findButton.setEnabled(false);
			itemIdField.setEditable(false);
			qtyField.setEditable(false);
		}

		// ENTER returns to Find
		getRootPane().setDefaultButton(findButton);
		itemIdField.requestFocusInWindow();
	}

	// ===== Behavior: Delete Last Item From Cart =====

	/**
	 * Remove the most recently added line, update subtotal and UI state.
	 * (Keeps the flow simple without random access edits.)
	 */

	private void onDeleteLast() {
		if (cart.isEmpty()) return;

		CartLine removed = cart.remove(cart.size() - 1);
		subtotal -= removed.lineTotal;

		if (subtotal < 0) subtotal = 0.0;

		// Step back the display index (but not below 1)
		if (itemIndex > 1) itemIndex--;
		findButton.setText("Find Item #" + itemIndex);
		addButton.setText("Add Item #" + itemIndex + " To Cart");
		subtotalLabel.setText("Order subtotal: " + currency.format(subtotal));

		// Re-open inputs and reset the pending selection
		itemIdField.setEditable(true);
		qtyField.setEditable(true);
		findButton.setEnabled(true);
		addButton.setEnabled(false);
		itemInfoArea.setText("");
		pendingItem = null;
		pendingQty = 0;

		renderCart();

		if (cart.isEmpty()) {
			deleteLastButton.setEnabled(false);
			checkoutButton.setEnabled(false);
		}

		getRootPane().setDefaultButton(findButton);
		itemIdField.requestFocusInWindow();
	}

	// ===== Behavior: Check Out =====

	/**
	 * Show a formatted invoice, append one CSV row per cart line to transactions.csv,
	 * then lock the UI (New Order / Exit are still available).
	 */

	private void onCheckout() {
		if (cart.isEmpty()) {
			JOptionPane.showMessageDialog(this, "Your cart is empty.");
			return;
		}

		double tax = round2(subtotal * TAX_RATE);
		double total = round2(subtotal + tax);

		// Generate IDs/timestamps in formats used by many course PDFs
		ZonedDateTime now = ZonedDateTime.now();
		String txnId = now.format(DateTimeFormatter.ofPattern("ddMMyyyyHHmmss"));
		String invoiceStamp = now.format(DateTimeFormatter.ofPattern("dd/MM/yyyy  HH:mm:ss  z"));

		// Build a monospace invoice (keeps columns aligned)
		StringBuilder inv = new StringBuilder();
		inv.append("Nile Dot Com - Invoice\n");
		inv.append("Date/Time: ").append(invoiceStamp).append("\n");
		inv.append("Transaction ID: ").append(txnId).append("\n\n");
		inv.append(String.format("%-8s %-12s %-32s %8s %6s %8s%n",
			"Item#", "ID", "Description", "Unit", "Qty", "Line"));
		inv.append("--------------------------------------------------------------------------\n");

		for (int i = 0; i < cart.size(); i++) {
			CartLine c = cart.get(i);
			inv.append(String.format("%-8s %-12s %-32.32s %8s %6d %8s%n",
				"#" + (i + 1),
				c.id,
				c.description,
				currency.format(c.unitPrice),
				c.qty,
				currency.format(c.lineTotal)
			));
		}

		inv.append("\n");
		inv.append(String.format("%-20s %s%n", "Order Subtotal:", currency.format(subtotal)));
		inv.append(String.format("%-20s %s%n", "Tax (6%):", currency.format(tax)));
		inv.append(String.format("%-20s %s%n", "Order Total:", currency.format(total)));

		// Show the invoice in a scrollable dialog
		JTextArea invoiceArea = new JTextArea(inv.toString());
		invoiceArea.setEditable(false);
		invoiceArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
		JOptionPane.showMessageDialog(this, new JScrollPane(invoiceArea),
			"Invoice", JOptionPane.INFORMATION_MESSAGE);

		// Persist the transaction (append-only; one row per line)
		appendTransactionCsv(txnId, now, tax, total);

		// Lock the order (consistent with assignment behavior)
		itemIdField.setEditable(false);
		qtyField.setEditable(false);
		findButton.setEnabled(false);
		addButton.setEnabled(false);
		deleteLastButton.setEnabled(false);
		checkoutButton.setEnabled(false);
		// Exit remains enabled; New Order can start another session
	}

	/**
	 * Append all cart lines to transactions.csv, creating a header if file does not exist.
	 */

	private void appendTransactionCsv(String txnId, ZonedDateTime when, double tax, double total) {
		Path p = Paths.get("transactions.csv");
		DateTimeFormatter iso = DateTimeFormatter.ISO_OFFSET_DATE_TIME;

		List<String> lines = new ArrayList<>();

		for (CartLine c: cart) {
			lines.add(String.join(",",
				quote(txnId),
				quote(when.format(iso)),
				quote(c.id),
				quote(c.description),
				Integer.toString(c.qty),
				Double.toString(round2(c.unitPrice)),
				Integer.toString((int) Math.round(c.discountRate * 100.0)),
				Double.toString(round2(c.lineTotal)),
				Double.toString(round2(subtotal)),
				Double.toString(round2(tax)),
				Double.toString(round2(total))
			));
		}

		try {
			if (!Files.exists(p)) {
				// Header row written once when file is created
				Files.write(p,
					List.of("txn_id,timestamp,item_id,description,qty,unit_price,discount_percent,line_total,order_subtotal,tax,total"),
					StandardCharsets.UTF_8,
					StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
			}

			Files.write(p, lines, StandardCharsets.UTF_8,
				StandardOpenOption.APPEND, StandardOpenOption.CREATE);
		} catch (IOException e) {
			JOptionPane.showMessageDialog(this,
				"Error writing transactions.csv:\n" + e.getMessage(),
				"File Write Error", JOptionPane.ERROR_MESSAGE);
		}
	}

	// ===== Small helpers =====
	private static String quote(String s) {
		return "\"" + s.replace("\"", "\"\"") + "\"";
	}

	private static double round2(double v) {
		return Math.round(v * 100.0) / 100.0;
	}

	/**
	 * Rebuild the cart text area from the in-memory list.
	 */

	private void renderCart() {
		StringBuilder sb = new StringBuilder();

		for (int i = 0; i < cart.size(); i++) {
			CartLine cl = cart.get(i);
			sb.append(String.format(
				"Item #%d -- %s \"%s\"  %s  x%d  Disc: %.0f%%  Line: %s%n",
				(i + 1),
				cl.id,
				cl.description,
				currency.format(cl.unitPrice),
				cl.qty,
				cl.discountRate * 100.0,
				currency.format(cl.lineTotal)
			));
		}

		cartArea.setText(sb.toString());
	}

	// ===== Reset for New Order =====

	/**
	 * Clear all order state and return to the initial Find flow.
	 */

	private void resetForNewOrder() {
		itemIndex = 1;
		itemIdField.setText("");
		qtyField.setText("");
		findButton.setText("Find Item #1");
		addButton.setText("Add Item #1 To Cart");
		itemInfoArea.setText("");

		cart.clear();
		cartArea.setText("");
		subtotal = 0.0;
		subtotalLabel.setText("Order subtotal: $0.00");

		itemIdField.setEditable(true);
		qtyField.setEditable(true);
		findButton.setEnabled(true);
		addButton.setEnabled(false);
		deleteLastButton.setEnabled(false);
		checkoutButton.setEnabled(false);

		pendingItem = null;
		pendingQty = 0;

		getRootPane().setDefaultButton(findButton);
		itemIdField.requestFocusInWindow();
	}

	// ===== Appearance helpers =====

	/**
	 * Install Nimbus L&F and slightly larger default fonts for readability.
	 * (Call before creating the frame in main.)
	 */

	private static void installLookAndFeel() {
		try {
			for (UIManager.LookAndFeelInfo info: UIManager.getInstalledLookAndFeels()) {
				if ("Nimbus".equals(info.getName())) {
					UIManager.setLookAndFeel(info.getClassName());
					break;
				}
			}
			// Subtle font bump for a more modern feel without changing layout code
			Font base = UIManager.getFont("Label.font");

			if (base != null) {
				Font bigger = base.deriveFont(base.getSize2D() + 1.5f);
				UIManager.put("Label.font", bigger);
				UIManager.put("Button.font", bigger);
				UIManager.put("TextField.font", bigger);
				UIManager.put("TextArea.font", base.deriveFont(base.getSize2D() + 1f));
				UIManager.put("OptionPane.messageFont", bigger);
				UIManager.put("OptionPane.buttonFont", bigger);
			}
		} catch (Exception ignored) {}
	}

	/**
	 * Minor UI polish: padding, borders, consistent button sizing, helpful tooltips.
	 */

	private void applyStyling() {
		((JComponent) getContentPane()).setBorder(BorderFactory.createEmptyBorder(10, 12, 12, 12));

		itemInfoArea.setLineWrap(true);
		itemInfoArea.setWrapStyleWord(true);
		itemInfoArea.setBorder(BorderFactory.createCompoundBorder(
			BorderFactory.createLineBorder(new Color(220, 220, 220)),
			BorderFactory.createEmptyBorder(8, 8, 8, 8)));

		cartArea.setLineWrap(true);
		cartArea.setWrapStyleWord(true);
		cartArea.setBorder(BorderFactory.createCompoundBorder(
			BorderFactory.createLineBorder(new Color(220, 220, 220)),
			BorderFactory.createEmptyBorder(8, 8, 8, 8)));
		cartArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, cartArea.getFont().getSize()));

		subtotalLabel.setFont(subtotalLabel.getFont().deriveFont(Font.BOLD));

		// Buttons sized wide enough to avoid truncation in Nimbus
		Dimension bottomBtn = new Dimension(220, 36); // longest label fits
		Dimension findBtn = new Dimension(200, 36);
		findButton.setPreferredSize(findBtn);

		for (JButton b: new JButton[] {
				addButton, deleteLastButton, checkoutButton, newOrderButton, exitButton
			}) {
			b.setPreferredSize(bottomBtn);
			b.setFocusPainted(false);
			b.setToolTipText(b.getText());
		}

		// Inner padding for inputs
		itemIdField.setBorder(BorderFactory.createCompoundBorder(
			itemIdField.getBorder(), BorderFactory.createEmptyBorder(4, 6, 4, 6)));
		qtyField.setBorder(BorderFactory.createCompoundBorder(
			qtyField.getBorder(), BorderFactory.createEmptyBorder(4, 6, 4, 6)));

		// Tooltips as lightweight guidance
		itemIdField.setToolTipText("Enter an item ID from inventory.csv");
		qtyField.setToolTipText("Enter a positive quantity");
		findButton.setToolTipText("Look up the item and show details");
		addButton.setToolTipText("Add the selected item to the cart");
		deleteLastButton.setToolTipText("Remove the most recently added cart item");
		checkoutButton.setToolTipText("Show invoice and write to transactions.csv");
		newOrderButton.setToolTipText("Clear the cart and start a new order");
		exitButton.setToolTipText("Close the application");
	}

	/**
	 * Add right-click Copy/Paste menus to inputs and read-only areas.
	 * (Paste disabled in read-only text areas.)
	 */

	private void installContextMenus() {
		addPopupMenu(itemIdField, true);
		addPopupMenu(qtyField, true);
		addPopupMenu(itemInfoArea, false);
		addPopupMenu(cartArea, false);
	}

	private void addPopupMenu(JTextComponent comp, boolean editable) {
		JPopupMenu menu = new JPopupMenu();
		JMenuItem miCut = new JMenuItem("Cut");
		JMenuItem miCopy = new JMenuItem("Copy");
		JMenuItem miPaste = new JMenuItem("Paste");
		JMenuItem miSelectAll = new JMenuItem("Select All");

		miCut.addActionListener(e -> comp.cut());
		miCopy.addActionListener(e -> comp.copy());
		miPaste.addActionListener(e -> comp.paste());
		miSelectAll.addActionListener(e -> comp.selectAll());

		miCut.setEnabled(editable);
		miPaste.setEnabled(editable);

		menu.add(miCut);
		menu.add(miCopy);
		menu.add(miPaste);
		menu.addSeparator();
		menu.add(miSelectAll);

		comp.setComponentPopupMenu(menu);
	}

	// ===== Entry point =====
	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> {
			installLookAndFeel(); // set Nimbus + fonts before creating UI
			new NileStoreApp().setVisible(true);
		});
	}
}