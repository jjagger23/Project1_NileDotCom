package estore;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/*
    Name:  Joshua Jaggernauth
    Course: CNT 4714 – Fall 2025
    Assignment title: Project 1 – An Event-driven Enterprise Simulation
    Date: Sunday September 7, 2025
*/


public class CSVLoader {

	/**
	 * Load inventory from a CSV file in the project root (same level as src/).
	 *
	 * Expected column order (5 columns total):
	 *   0: item id (String)
	 *   1: description (String, may be quoted; quotes are preserved then unwrapped)
	 *   2: in-stock flag (e.g., "true", "yes", "y" → true; anything else → false)
	 *   3: quantity on hand (int)
	 *   4: unit price (double)
	 *
	 * Lines that are empty or malformed (≠ 5 columns) are skipped.
	 */

	public static Map<String, InventoryItem> loadInventory(String filename) throws IOException {
		Map<String, InventoryItem> map = new HashMap<>();

		Path path = Paths.get(filename);
		// Use UTF-8 to match typical CSV encoding and avoid platform defaults.
		try (BufferedReader br = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
			String line;

			while ((line = br.readLine()) != null) {
				line = line.trim();

				if (line.isEmpty()) continue; // ignore blank lines

				// Split respecting quoted commas (e.g., "ACME, Inc.")
				List<String> cols = splitCsv(line);

				if (cols.size() != 5) continue; // defensive: skip malformed rows
				String id = cols.get(0).trim();

				// Description may come in quotes from the CSV; unwrap if so.
				String desc = unquote(cols.get(1).trim());

				// Be tolerant with "true/yes/y" for the in-stock field.
				String inStockStr = cols.get(2).trim().toLowerCase(Locale.ROOT);
				boolean inStock = inStockStr.equals("true") || inStockStr.equals("yes") || inStockStr.equals("y");

				// Parse integer/double; let NumberFormatExceptions bubble up to caller if file is corrupt.
				int qoh = Integer.parseInt(cols.get(3).trim());
				double price = Double.parseDouble(cols.get(4).trim());

				map.put(id, new InventoryItem(id, desc, inStock, qoh, price));
			}
		}

		return map;
	}

	/**
	 * Remove a single leading/trailing quote pair if present.
	 * (We intentionally leave inner quotes as-is.)
	 */

	private static String unquote(String s) {
		if (s.length() >= 2 && s.startsWith("\"") && s.endsWith("\"")) {
			return s.substring(1, s.length() - 1);
		}

		return s;
	}

	/**
	 * Minimal CSV splitter that respects quoted commas.
	 * - Toggles an inQuotes flag when encountering a double-quote.
	 * - Only splits on commas that occur outside of quoted regions.
	 * - Keeps quotes in the token so the caller can decide how to handle them (see unquote()).
	 *
	 * Note: This is intentionally lightweight—good enough for the assignment’s CSV shape.
	 *       For production-grade CSV, consider a library (e.g., OpenCSV) to handle escapes, CRLFs, etc.
	 */

	private static List<String> splitCsv(String line) {
		List<String> out = new ArrayList<>();
		StringBuilder cur = new StringBuilder();
		boolean inQuotes = false;

		for (int i = 0; i < line.length(); i++) {
			char c = line.charAt(i);

			if (c == '"') {
				// Toggle quoted-region tracking and keep the quote for later unwrapping.
				inQuotes = !inQuotes;
				cur.append(c);
			} else if (c == ',' && !inQuotes) {
				// Comma outside quotes → end of token.
				out.add(cur.toString().trim());
				cur.setLength(0);
			} else {
				cur.append(c);
			}
		}

		// Add the final token.
		out.add(cur.toString().trim());
		return out;
		// (No trailing comma handling needed; the loop appends the last token above.)
	}
}